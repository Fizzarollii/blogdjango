from django.urls import path
from . import views

urlpatterns = [
    path('', views.home, name='home'),
    path('about/', views.about, name='about'),
    path('pages/', views.blog_list, name='blog_list'),
    path('pages/<int:page_id>/', views.blog_detail, name='blog_detail'),
]