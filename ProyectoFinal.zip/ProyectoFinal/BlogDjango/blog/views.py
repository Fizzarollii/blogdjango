from django.shortcuts import render, get_object_or_404
from .models import Blog

def home(request):
    return render(request, 'blog/home.html')

def about(request):
    return render(request, 'blog/about.html')

def blog_list(request):
    blogs = Blog.objects.all()
    if not blogs:
        return render(request, 'blog/no_blogs.html')
    return render(request, 'blog/blog_list.html', {'blogs': blogs})

def blog_detail(request, page_id):
    blog = get_object_or_404(Blog, pk=page_id)
    return render(request, 'blog/blog_detail.html', {'blog': blog})